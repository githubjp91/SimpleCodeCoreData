//
//  Student+CoreDataProperties.swift
//  coreDataDemo
//
//  Created by Mac on 6/28/18.
//  Copyright © 2018 agile. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit

extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var name: String?
    @NSManaged public var address: String?
    @NSManaged public var city: String?
    @NSManaged public var mobile: String?

}
