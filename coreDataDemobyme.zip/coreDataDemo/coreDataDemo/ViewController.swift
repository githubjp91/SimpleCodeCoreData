//
//  ViewController.swift
//  coreDataDemo
//
//  Created by Mac on 6/28/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func btnSave(_ sender: UIButton)
    {
        
        let dic:[String:String] = ["name":txtName.text!,"address":txtAddress.text!,"city":txtCity.text!,"mobile":txtMobile.text!]
        
         DataHelper.sharedInstance.save(object: dic)
        
        
      
        
    }
   

}

