//
//  secViewController.swift
//  coreDataDemo
//
//  Created by Mac on 6/28/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class secViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
   
    

    @IBOutlet weak var tblView: UITableView!
    
    var aryList = [Student]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //self.tblView.register(UITableViewCell.self, forCellReuseIdentifier: "cusTableViewCell")
        
    self.tblView.register(cusTableViewCell.self, forCellReuseIdentifier: "cusTableViewCell")
        
       // self.tblView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        
        
        
        aryList = DataHelper.sharedInstance.getAllData()
        
      
       
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:cusTableViewCell =  tableView.dequeueReusableCell(withIdentifier: "cusTableViewCell", for: indexPath) as! cusTableViewCell
        
        cell.lblName.text = aryList[indexPath.row].name
        cell.lblAddress.text = aryList[indexPath.row].address
        cell.lblCity.text = aryList[indexPath.row].city
        cell.lblMobile.text = aryList[indexPath.row].mobile
        
        
        return cell
        
    }

}

