//
//  Student+CoreDataClass.swift
//  coreDataDemo
//
//  Created by Mac on 6/28/18.
//  Copyright © 2018 agile. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

    
    static let entityName = "Student"
}
