//
//  File.swift
//  coreDataDemo
//
//  Created by Mac on 6/28/18.
//  Copyright © 2018 agile. All rights reserved.
//

import Foundation
import  UIKit
import CoreData


class DataHelper
{
    static let sharedInstance = DataHelper()
    
     let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func save(object:[String:String])
    {
        
        let entityName = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context)as! Student
        
        entityName.name = object["name"]
        entityName.address = object["address"]
        entityName.city = object["city"]
        entityName.mobile = object["mobile"]
        do{
            
                try context.save()
            
        }
        catch
        {
            print("No Data Found")
        }
        
    
        
    }
    
    func getAllData() -> [Student]
    {
        
        var stud:[Student] = []
        let fetchrequest = NSFetchRequest<NSManagedObject>(entityName: "Student")
        
        do{
            stud = try context.fetch(fetchrequest)as! [Student]
            
        }catch{
            print("not get data")
        }
        return stud
       
    }
    
//    func getById(id: NSManagedObjectID) -> NSManagedObject{
//        let contextNew = context
//        return context.object(with: id)
//    }
//    
//    
//    
//    func deleteEmployee(id: NSManagedObjectID){
//        let contextNew = context
//        let sugerToDelete = getById(id: id)
//        context.delete(sugerToDelete)
//        do{
//            try context.save()
//            print("saved.")
//        }catch{
//            print(error.localizedDescription)
//        }
//    }
    
    
}
